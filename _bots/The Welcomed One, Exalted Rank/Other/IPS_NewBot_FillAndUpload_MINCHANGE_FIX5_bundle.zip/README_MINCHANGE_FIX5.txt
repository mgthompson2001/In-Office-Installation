FIX5: Removed the date from the Welcome Letter overlay.
Packet still includes date; Letter now prints only:
  1) Client Name
  2) Street - Unit (if any)
  3) City ST
  4) United States ZIP
